from wtforms import Form, StringField, validators, PasswordField
from wtforms.fields import EmailField, DateField


class CreateAccountform(Form):
    first_name = StringField("", [validators.DataRequired()])
    last_name = StringField("", [validators.DataRequired()])
    email = EmailField("", [validators.DataRequired()])
    password = PasswordField('', [validators.DataRequired()])
    date = DateField("", [validators.optional()])


class UpdateAccountform(Form):
    first_names = StringField("", [validators.DataRequired()])
    last_names = StringField("", [validators.DataRequired()])
    date = DateField("", [validators.optional()])


class UpdateAccountform2(Form):
    first_names2 = StringField("", [validators.DataRequired()])
    last_names2 = StringField("", [validators.DataRequired()])
    date2 = DateField("", [validators.optional()])


class UpdateAccountPassword(Form):
    new_passwords = PasswordField('', validators=[
        validators.DataRequired(),
        validators.EqualTo('confirm_new_passwords', message='*Passwords must match*')
    ])
    new_password = PasswordField('', validators=[
        validators.DataRequired(),
        validators.EqualTo('confirm_new_password', message='*Passwords must match*')
    ])
    confirm_new_password = PasswordField('', [validators.DataRequired()])
    confirm_new_passwords = PasswordField('', [validators.DataRequired()])


class UpdateAccountPasswords(Form):
    new_passwords = PasswordField('', validators=[
        validators.DataRequired(),
        validators.EqualTo('confirm_new_passwords', message='*Passwords must match*')
    ])
    confirm_new_passwords = PasswordField('', [validators.DataRequired()])
    new_password = PasswordField('', validators=[
        validators.DataRequired(),
        validators.EqualTo('confirm_new_password', message='*Passwords must match*')
    ])
    confirm_new_password = PasswordField('', [validators.DataRequired()])


class LoginAccountform(Form):
    emails = EmailField("", [validators.DataRequired()])
    passwords = PasswordField('', [validators.DataRequired()])
