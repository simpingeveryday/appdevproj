class User():
    def __init__(self, first_name, last_name, email, password, date):
        self.__first_name = first_name
        self.__last_name = last_name
        self.__email = email
        self.__password = password
        self.__date = date

    def get_first_name(self):
        return self.__first_name

    def get_last_name(self):
        return self.__last_name

    def get_email(self):
        return self.__email

    def get_password(self):
        return self.__password

    def get_date(self):
        return self.__date

    def set_first_name(self, first_name):
        self.__first_name = first_name

    def set_last_name(self, last_name):
        self.__last_name = last_name

    def set_email(self, e):
        self.__email = e

    def set_password(self, p):
        self.__password = p

    def set_date(self, date):
        self.__date = date


class Admins(User):
    def __init__(self, first_name, last_name, email, password, date, staff_id):
        super().__init__(first_name, last_name, email, password, date)
        self.__staff_id = staff_id

    def get_staff_id(self):
        return self.__staff_id

    def set_staff_id(self, staff_id):
        self.__staff_id = staff_id


class Customer(User):
    def __init__(self, first_name, last_name, email, password, date):
        super().__init__(first_name, last_name, email, password, date)
