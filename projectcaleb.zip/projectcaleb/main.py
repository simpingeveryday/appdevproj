from flask import Flask, render_template, request, redirect, url_for, session
import os
import shelve
from forms import *
from user import *

BASEDIR = os.getcwd()
app = Flask(__name__, template_folder=f"{BASEDIR}/templates",
            static_folder=f"{BASEDIR}/static", )

app.secret_key = "jumptodamoon"


@app.route('/home2')
def home2():
    db = shelve.open("users.db", "r")
    users_dict = db["users"]
    db.close()
    users_list = []
    print(session['users'])
    current_user = users_dict.get(session['users'])
    for key in users_dict:
        user = users_dict.get(key)
        users_list.append(user)
    return render_template('home/home2.html', current_user=current_user)


@app.route('/')
def home():
    return render_template('home/home.html')


@app.route('/login', methods=["POST", "GET"])
def login():
    session['users'] = None
    login_form = LoginAccountform(request.form)
    if request.method == "POST" and login_form.validate():
        db = shelve.open('users.db', 'r')
        users_dict = db['users']
        db.close()
        users_email = []
        for key in users_dict:
            users_email.append(key)
        email = login_form.emails.data
        password = login_form.passwords.data
        if email in users_email:
            current_user = users_dict.get(email)
            if password == current_user.get_password():
                print(email)
                session['users'] = email
                return redirect(url_for("home2"))
        return redirect(url_for("login"))
    return render_template('login/login.html', form=login_form)


@app.route('/create_account', methods=["GET", "POST"])
def create_account():
    users_dict = {}
    create_form = CreateAccountform(request.form)
    if request.method == "POST" and create_form.validate():
        db = shelve.open('users.db', 'c')
        try:
            users_dict = db['users']
        except:
            print("unable to retrieve")

        user = Customer(create_form.first_name.data, create_form.last_name.data, create_form.email.data,
                        create_form.password.data, create_form.date.data)

        users_dict[user.get_email()] = user
        db["users"] = users_dict
        db.close()
        return redirect(url_for("createaccount"))
    return render_template('login/create_account.html', form=create_form)


@app.route('/retrieve_users')
def retrieve_users():
    db = shelve.open("users.db", "r")
    users_dict = db["users"]
    db.close()
    users_list = []
    for key in users_dict:
        user = users_dict.get(key)
        users_list.append(user)
    return render_template('login/retrieve_users.html', users_list=users_list)


@app.route('/deleteUser/<id>', methods=['POST'])
def delete_user(id):
    users_dict = {}
    db = shelve.open('users.db', 'w')
    users_dict = db['users']
    users_dict.pop(id)
    db['users'] = users_dict
    db.close()
    return redirect(url_for('retrieve_users'))


@app.route('/updateUserPassword/<id>/', methods=['GET', 'POST'])
def update_user_password_form(id):
    update_user_password = UpdateAccountPassword(request.form)
    if request.method == "POST" and update_user_password.validate():
        db = shelve.open('users.db', 'c')
        users_dict = db['users']
        user = users_dict.get(id)
        user.set_password(update_user_password.new_password.data)
        db['users'] = users_dict
        db.close()
        return redirect(url_for("create_account"))
    else:
        db = shelve.open('users.db', 'r')
        users_dict = db['users']
        db.close()
        user = users_dict.get(id)
        update_user_password.new_password.data = user.get_password()
    return render_template('login/updateUserPassword.html', form=update_user_password)


@app.route('/updateUserPasswords/<id>/', methods=['GET', 'POST'])
def update_user_password_forms(id):
    update_user_passwords = UpdateAccountPasswords(request.form)
    db = shelve.open("users.db", "r")
    users_dict = db["users"]
    db.close()
    users_list = []
    print(session['users'])
    current_user = users_dict.get(session['users'])
    for key in users_dict:
        user = users_dict.get(key)
        users_list.append(user)
    if request.method == "POST" and update_user_passwords.validate():
        db = shelve.open('users.db', 'c')
        users_dict = db['users']
        user = users_dict.get(id)
        user.set_password(update_user_passwords.new_passwords.data)
        db['users'] = users_dict
        db.close()
        return redirect(url_for("create_account"))
    else:
        db = shelve.open('users.db', 'r')
        users_dict = db['users']
        db.close()
        user = users_dict.get(id)
        update_user_passwords.new_passwords.data = user.get_password()
    return render_template('login/updateUserPassword2.html', form=update_user_passwords, current_user=current_user)


@app.route('/updateUsers/<id>/', methods=['GET', 'POST'])
def update_users(id):
    update_user_forms = UpdateAccountform2(request.form)
    db = shelve.open("users.db", "r")
    users_dict = db["users"]
    db.close()
    users_list = []
    print(session['users'])
    current_user = users_dict.get(session['users'])
    for key in users_dict:
        user = users_dict.get(key)
        users_list.append(user)
    if request.method == "POST" and update_user_forms.validate():
        db = shelve.open('users.db', 'c')
        users_dict = db['users']
        user = users_dict.get(id)
        user.set_first_name(update_user_forms.first_names2.data)
        user.set_last_name(update_user_forms.last_names2.data)
        user.set_date(update_user_forms.date2.data)
        db['users'] = users_dict
        db.close()
        return redirect(url_for("home2"))
    else:
        db = shelve.open('users.db', 'r')
        users_dict = db['users']
        db.close()
        user = users_dict.get(id)
        update_user_forms.first_names2.data = user.get_first_name()
        update_user_forms.last_names2.data = user.get_last_name()
        update_user_forms.date2.data = user.get_date()
    return render_template('login/updateUser2.html', form=update_user_forms, current_user=current_user)


@app.route('/updateUser/<id>/', methods=['GET', 'POST'])
def update_user(id):
    update_user_form = UpdateAccountform(request.form)
    if request.method == "POST" and update_user_form.validate():
        db = shelve.open('users.db', 'c')
        users_dict = db['users']
        user = users_dict.get(id)
        user.set_first_name(update_user_form.first_names.data)
        user.set_last_name(update_user_form.last_names.data)
        user.set_date(update_user_form.date.data)
        db['users'] = users_dict
        db.close()
        return redirect(url_for("create_account"))
    else:
        db = shelve.open('users.db', 'r')
        users_dict = db['users']
        db.close()
        user = users_dict.get(id)
        update_user_form.first_names.data = user.get_first_name()
        update_user_form.last_names.data = user.get_last_name()
        update_user_form.date.data = user.get_date()
    return render_template('login/updateUser.html', form=update_user_form)


@app.route('/faq')
def faq():
    return render_template('FAQ/faq.html')


@app.route('/faq1')
def faq1():
    return render_template('FAQ/faq1.html')


@app.route('/faq2')
def faq2():
    return render_template('FAQ/faq2.html')


@app.route('/faq3')
def faq3():
    return render_template('FAQ/faq3.html')


@app.route('/faq4')
def faq4():
    return render_template('FAQ/faq4.html')


@app.route('/faq5')
def faq5():
    return render_template('FAQ/faq5.html')


@app.route('/faq6')
def faq6():
    db = shelve.open("users.db", "r")
    users_dict = db["users"]
    db.close()
    users_list = []
    print(session['users'])
    current_user = users_dict.get(session['users'])
    for key in users_dict:
        user = users_dict.get(key)
        users_list.append(user)
    return render_template('FAQ/faq6.html', current_user=current_user)


@app.route('/faq7')
def faq7():
    db = shelve.open("users.db", "r")
    users_dict = db["users"]
    db.close()
    users_list = []
    print(session['users'])
    current_user = users_dict.get(session['users'])
    for key in users_dict:
        user = users_dict.get(key)
        users_list.append(user)
    return render_template('FAQ/faq7.html', current_user=current_user)


@app.route('/faq8')
def faq8():
    db = shelve.open("users.db", "r")
    users_dict = db["users"]
    db.close()
    users_list = []
    print(session['users'])
    current_user = users_dict.get(session['users'])
    for key in users_dict:
        user = users_dict.get(key)
        users_list.append(user)
    return render_template('FAQ/faq8.html', current_user=current_user)


@app.route('/faq9')
def faq9():
    db = shelve.open("users.db", "r")
    users_dict = db["users"]
    db.close()
    users_list = []
    print(session['users'])
    current_user = users_dict.get(session['users'])
    for key in users_dict:
        user = users_dict.get(key)
        users_list.append(user)
    return render_template('FAQ/faq9.html', current_user=current_user)


@app.route('/faq10')
def faq10():
    db = shelve.open("users.db", "r")
    users_dict = db["users"]
    db.close()
    users_list = []
    print(session['users'])
    current_user = users_dict.get(session['users'])
    for key in users_dict:
        user = users_dict.get(key)
        users_list.append(user)
    return render_template('FAQ/faq10.html', current_user=current_user)


@app.route('/faq11')
def faq11():
    db = shelve.open("users.db", "r")
    users_dict = db["users"]
    db.close()
    users_list = []
    print(session['users'])
    current_user = users_dict.get(session['users'])
    for key in users_dict:
        user = users_dict.get(key)
        users_list.append(user)
    return render_template('FAQ/faq11.html', current_user=current_user)


@app.route('/contactus')
def contactus():
    return render_template('ContactUs/contactus.html')


@app.route('/contactus2')
def contactus2():
    db = shelve.open("users.db", "r")
    users_dict = db["users"]
    db.close()
    users_list = []
    print(session['users'])
    current_user = users_dict.get(session['users'])
    for key in users_dict:
        user = users_dict.get(key)
        users_list.append(user)
    return render_template('ContactUs/contactus2.html', current_user=current_user)


@app.route('/createaccount')
def createaccount():
    return render_template('login/accountcreated.html')


@app.route('/adminlogin', methods=["POST", "GET"])
def adminlogin():
    session['users'] = None
    login_form = LoginAccountform(request.form)
    if request.method == "POST" and login_form.validate():
        db = shelve.open('users.db', 'r')
        users_dict = db['users']
        db.close()
        users_email = []
        for key in users_dict:
            users_email.append(key)
        email = login_form.emails.data
        password = login_form.passwords.data
        if email in users_email:
            current_user = users_dict.get(email)
            if password == current_user.get_password():
                print(email)
                session['users'] = email
                return redirect(url_for("home2"))
        return redirect(url_for("adminlogin"))
    return render_template('login/adminlogin.html', form=login_form)


if __name__ == "__main__":
    app.run(debug=True)
