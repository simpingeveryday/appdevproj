from flask import Flask, render_template

app = Flask(__name__)

@app_route()
    db = shelve.open("users.db", "r")
    users_dict = db["users"]
    db.close()
    users_list = []
    for key in users_dict:
        user = users_dict.get(key)
        users_list.append(user)