from flask import Blueprint, render_template, request, redirect
from voucher_forms import CreateUserForm, UpdateUserForm
from voucher import Voucher
from user_service import get_voucher_list, get_voucher, save_user
import os
from flask import current_app
# get_user_for_login LoginForm session

voucher_controller = Blueprint('voucher', __name__)


@voucher_controller.route('/viewvoucher')
def kljil_viewvoucher():
    voucher_list = get_voucher_list()
    return render_template('viewvoucher.html', count=len(voucher_list), voucher_list=voucher_list)

@voucher_controller.route('/retrieveVoucher')
def retrieve_users():
    voucher_list = get_voucher_list()
    return render_template('retrieveVoucher.html', count=len(voucher_list), voucher_list=voucher_list)

@voucher_controller.route('/createVoucher', methods=['GET', 'POST'])
def create_user():
    create_user_form = CreateUserForm(request.form)
    if request.method == 'POST' and create_user_form.validate():
        name = create_user_form.name.data
        category = create_user_form.category.data
        duration = create_user_form.duration.data
        remarks = create_user_form.remarks.data
        quantity = create_user_form.quantity.data
        points = create_user_form.points.data
        voucher = Voucher(name, category, quantity, points, remarks, duration)
        print(voucher)
        save_user(voucher)
        return redirect('/retrieveVoucher')
    else:
        return render_template('createVoucher.html', form=create_user_form)


@voucher_controller.route('/updateUser/<id>', methods=['GET', 'POST'])
def update_voucher(id):
    voucher = get_voucher(id)
    update_voucher_form = UpdateUserForm(request.form)
    if request.method == 'POST' and update_voucher_form.validate():
        voucher.name = update_voucher_form.name.data
        voucher.category = update_voucher_form.category.data
        voucher.duration = update_voucher_form.duration.data
        voucher.remarks = update_voucher_form.remarks.data
        voucher.quantity = update_voucher_form.quantity.data
        voucher.points = update_voucher_form.points.data

        uploaded_file = request.files['image_file']
        if uploaded_file.filename != '':
            new_filename = f'{voucher.id}.jpg'
            uploaded_file.save(
                os.path.join(os.path.dirname(current_app.instance_path),
                             "static\\images", new_filename))
            voucher.profile_image = new_filename
        print(voucher)
        save_user(voucher)
        return redirect('/retrieveVoucher')
    else:
        update_voucher_form.name.data = voucher.name
        update_voucher_form.category.data = voucher.category
        update_voucher_form.duration.data = voucher.duration
        update_voucher_form.remarks.data = voucher.remarks
        update_voucher_form.quantity.data = voucher.quantity
        update_voucher_form.points.data = voucher.points
        return render_template('updateUser.html', form=update_voucher_form, voucher=voucher)


@voucher_controller.route('/deleteUser/<id>', methods=['POST'])
def delete_user(id):
    user = get_voucher(id)
    user.status = Voucher.status_deleted
    save_user(user)
    return redirect('/retrieveVoucher')


# @user_controller.route('/login', methods=['GET', 'POST'])
# def login():
#     login_form = LoginForm(request.form)
#     if request.method == 'POST' and login_form.validate():
#         email = login_form.email.data
#         password = login_form.password.data
#         user = get_user_for_login(email, password)
#         if user is not None:
#             session['user_name'] = user.name
#             session['user_type'] = user.user_type
#             return redirect('/')
#         else:
#             error = 'Invalid email or password'
#             return render_template('login.html', form=login_form, error=error)
#     else:
#         return render_template('login.html', form=login_form)
#
#
# @user_controller.route('/logout')
# def logout():
#     session.pop('user_name', None)
#     session.pop('user_type', None)
#     return redirect('/')
