from flask import Flask, render_template
from voucher_controller import voucher_controller


app = Flask(__name__)
app.register_blueprint(voucher_controller)
app.secret_key = 'MyFlaskWebAppKey'
app.config['SECRET_KEY'] = 'mysecretkey'

@app.route('/', methods=['GET', 'POST'])
def home():
    return render_template('home.html')


@app.route('/viewvoucher')
def viewvoucher():
    return render_template('viewvoucher.html')


@app.route('/contactUs')
def contact_us():
    return render_template('contactUs.html')


if __name__ == '__main__':
    app.run(port=5001)
