import shelve
from datetime import datetime
# from voucher import Voucher

db_name = 'library'
db_voucher_key = 'voucher'


def check_status(voucher):
    return voucher.status > 0


def by_time_updated(voucher):
    return voucher.time_updated


def get_voucher_list():
    voucher_dict = {}
    db = shelve.open(db_name)
    if db_voucher_key in db:
        voucher_dict = db[db_voucher_key]
    db.close()
    voucher_list = voucher_dict.values()
    voucher_list = filter(check_status, voucher_list)
    voucher_list = sorted(voucher_list, key=by_time_updated, reverse=True)
    return voucher_list


def get_voucher(id):
    result = None
    voucher_dict = {}
    db = shelve.open(db_name)
    if db_voucher_key in db:
        voucher_dict = db[db_voucher_key]
    db.close()
    if id in voucher_dict:
        result = voucher_dict[id]
    return result


# def get_user_for_login(email, password):
#     result = None
#     user_dict = {}
#     db = shelve.open(db_name)
#     if db_users_key in db:
#         user_dict = db[db_users_key]
#     db.close()
#     for user in user_dict.values():
#         if user.email == email and \
#                 user.password == password and \
#                 user.status == .status_active:
#             result = user
#     return result


def save_user(voucher):
    voucher.time_updated = datetime.now()
    user_dict = {}
    db = shelve.open(db_name)
    if db_voucher_key in db:
        user_dict = db[db_voucher_key]
    user_dict[voucher.id] = voucher
    db[db_voucher_key] = user_dict
    db.close()
