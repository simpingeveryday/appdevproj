# Note: Use wtforms v3.0.0
from wtforms import Form, StringField, TextAreaField, DateField, IntegerField, \
    validators
# from voucher import Voucher

class CreateUserForm(Form):
    name = StringField('Name', [validators.Length(min=1, max=150), validators.DataRequired()])
    category = StringField('Category', [validators.DataRequired()])
    quantity = IntegerField('Quantity', [validators.InputRequired(), validators.DataRequired()])
    points = IntegerField('Points', [validators.InputRequired(), validators.DataRequired()])
    duration = DateField('Duration until', [validators.Optional()])
    remarks = TextAreaField('Remarks', [validators.Optional()])


class UpdateUserForm(Form):
    name = StringField('Name', [validators.Length(min=1, max=150), validators.DataRequired()])
    category = StringField('Category', [validators.DataRequired()])
    quantity = IntegerField('Quantity', [validators.InputRequired(), validators.DataRequired()])
    points = IntegerField('Points', [validators.InputRequired(), validators.DataRequired()])
    duration = DateField('Duration until', [validators.Optional()])
    remarks = TextAreaField('Remarks', [validators.Optional()])

# class LoginForm(Form):
#     email = EmailField('Email', [validators.DataRequired(), validators.Email()])
#     password = PasswordField('Password', [validators.Length(min=6, max=15), validators.DataRequired()])
