import uuid
from datetime import datetime
from constants import date_format, datetime_format


class Voucher:
    # gender_dict = {
    #     '': 'Select', 'F': 'Female', 'M': 'Male'
    # }
    # membership_dict = {
    #     'F': 'Fellow', 'S': 'Senior', 'P': 'Professional'
    # }
    # user_type_dict = {
    #     'C': 'Customer', 'S': 'Staff'
    # }

    status_active = 1
    status_deleted = 0

    def __init__(self, name, category, quantity, points, remarks, duration=None):
        self.id = str(uuid.uuid4())
        self.name = name
        self.category = category
        self.quantity = quantity
        self.points = points
        self.remarks = remarks
        self.duration = duration
        self.status = Voucher.status_active
        self.time_created = datetime.now()
        self.time_updated = datetime.now()
        self.profile_image = None

    # def get_name_str(self):
    #     return Voucher.name_dict[self.name]
    #
    # def get_membership_str(self):
    #     return Voucher.membership_dict[self.membership]
    #
    # def get_user_type_str(self):
    #     return Voucher.user_type_dict[self.user_type]

    def get_duration_str(self):
        if self.duration is None:
            return 'Unknown'
        else:
            print(self.duration)
            return self.duration.strftime(date_format)

    def get_time_created_str(self):

        return self.time_created.strftime(datetime_format)

    def get_time_updated_str(self):
        return self.time_updated.strftime(datetime_format)

    def __str__(self):
        return f'Name: {self.name}\n' \
               f'Category: {self.category}\n' \
               f'Remarks: {self.quantity}\n' \
               f'Status: {self.status}\n' \
               f'Points: {self.points}\n' \
               f'Duration: {self.get_duration_str()}\n' \
               f'Date Created: {self.get_time_created_str()}\n' \
               f'Date Updated: {self.get_time_updated_str()}\n' \



# user1 = User('user1@test.com', 'FlaskWebapp', 'Alice', 'F', 'F')
# print(user1)
# user2 = User('user2@test.com', 'FlaskWebapp', 'Bryan', 'M', 'P', 'I love python',
#              datetime.strptime('15/05/2005', date_format), 'S')
# print(user2)
